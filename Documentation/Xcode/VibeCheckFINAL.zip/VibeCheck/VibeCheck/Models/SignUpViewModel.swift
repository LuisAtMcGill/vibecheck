//
//  SignUpViewModel.swift
//  VibeCheck
//
//  Created by Aldo Serrano Rugerio on 29/04/25.
//

import FirebaseAuth
import FirebaseFirestore
import Firebase
import GoogleSignIn
import AuthenticationServices

@MainActor
final class SignUpViewModel: ObservableObject {
    // Campos del formulario
    @Published var email = ""
    @Published var name  = ""
    @Published var password = ""
    @Published var confirm  = ""

    // Estado de UI
    @Published var isLoading = false
    @Published var errorMessage: String?

    private let db = Firestore.firestore()

    // MARK: – Alta con correo / contraseña
    func createAccount() async {
        guard !email.isEmpty, !name.isEmpty else {
            errorMessage = "Complete your email and name."
            return
        }
        guard password == confirm else {
            errorMessage = "The passwords do not match."
            return
        }

        await runAuthFlow {
            try await Auth.auth().createUser(withEmail: email, password: password)
        }
    }

    // MARK: – Alta con Google (sin cambios salvo que guardamos el nombre ya traído por Google)
    func signUpWithGoogle() async {
        guard let clientID = FirebaseApp.app()?.options.clientID else { return }
        GIDSignIn.sharedInstance.configuration = .init(clientID: clientID)
        guard let rootVC = UIApplication.shared.firstKeyWindow?.rootViewController else { return }

        do {
            let result = try await GIDSignIn.sharedInstance.signIn(withPresenting: rootVC)
            guard
                let idToken = result.user.idToken?.tokenString
            else { return }

            let credential = GoogleAuthProvider.credential(withIDToken: idToken,
                                                           accessToken: result.user.accessToken.tokenString)

            // Name viene de la cuenta de Google
            name = result.user.profile?.name ?? ""

            await runAuthFlow {
                try await Auth.auth().signIn(with: credential)
            }
        } catch { errorMessage = error.localizedDescription }
    }

    // MARK: – Alta con Apple (capturamos nombre si el usuario lo comparte)
    func signUpWithApple(credential: ASAuthorizationAppleIDCredential) async {
        guard let tokenData = credential.identityToken,
              let tokenString = String(data: tokenData, encoding: .utf8) else { return }

        let firebaseCred = OAuthProvider.appleCredential(withIDToken: tokenString,
                                                         rawNonce: nil,
                                                         fullName: credential.fullName)

        // Apple sólo devuelve nombre en la primera ocasión
        if let fullName = credential.fullName,
           !fullName.givenName.orEmpty.isEmpty || !fullName.familyName.orEmpty.isEmpty {
            name = "\(fullName.givenName.orEmpty) \(fullName.familyName.orEmpty)".trimmingCharacters(in: .whitespaces)
        }

        await runAuthFlow {
            try await Auth.auth().signIn(with: firebaseCred)
        }
    }

    // MARK: – Helper común
    private func runAuthFlow(_ action: () async throws -> AuthDataResult) async {
        isLoading = true
        defer { isLoading = false }
        do {
            let authResult = try await action()
            let uid = authResult.user.uid

            // Actualizar displayName
            let change = authResult.user.createProfileChangeRequest()
            change.displayName = name
            try await change.commitChanges()

            // Crear documento en Firestore (si no existe)
            let ref = db.collection("users").document(uid)
            if try await ref.getDocument().exists == false {
                try await ref.setData([
                    "fullName": name,
                    "email"   : email,
                    "active"  : true,
                    "createdAt": FieldValue.serverTimestamp()
                ])
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

// Pequeño helper para evitar optionals vacíos
private extension Optional where Wrapped == String {
    var orEmpty: String { self ?? "" }
}
