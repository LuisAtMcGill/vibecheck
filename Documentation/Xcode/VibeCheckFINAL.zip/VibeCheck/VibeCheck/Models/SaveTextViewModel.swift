//
//  SaveTextViewModel.swift
//  VibeCheck
//
//  Created by Aldo Serrano Rugerio on 06/05/25.
//

import Foundation
import FirebaseFirestore
import FirebaseAuth

@MainActor
final class SaveTextViewModel: ObservableObject {
    // Ya no hay valor por defecto aquí:
    @Published var message: String
    @Published var rating: Int = 3
    @Published var isLoading = false
    @Published var errorMessage: String?

    private let ai = AISuggestionService()
    private let db = Firestore.firestore()

    /// Inicializa con el mensaje que le pase la vista
    init(initialMessage: String) {
        self.message = initialMessage
    }

    /// Pide a la IA el rating y lo asigna a `rating`.
    func rateMessage() async throws {
        let text = message.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else {
            throw NSError(domain: "SaveTextViewModel",
                          code: 0,
                          userInfo: [NSLocalizedDescriptionKey: "El mensaje no puede estar vacío."])
        }

        isLoading = true
        defer { isLoading = false }

        let stars = try await ai.rateMessage(text)
        rating = stars
    }

    /// Guarda en Firestore el mensaje actual junto con el `rating`.
    func saveMessage() async throws {
            guard let uid = Auth.auth().currentUser?.uid else {
                throw NSError(domain: "SaveTextViewModel",
                              code: 0,
                              userInfo: [NSLocalizedDescriptionKey: "Usuario no autenticado"])
            }

            let text = message.trimmingCharacters(in: .whitespacesAndNewlines)
            let data: [String: Any] = [
                "text":     text,
                "rating":   rating,
                "created":  Timestamp(date: Date()),
                "ownerId":  uid                // ← guardamos aquí el owner
            ]
            _ = try await db.collection("birthdayMessages").addDocument(data: data)
        }
}
