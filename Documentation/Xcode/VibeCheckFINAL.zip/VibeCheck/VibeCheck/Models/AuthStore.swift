//
//  AuthStore.swift
//  VibeCheck
//
//  Created by Aldo Serrano Rugerio on 05/05/25.
//

import FirebaseAuth
import Combine

@MainActor
final class AuthStore: ObservableObject {
    @Published private(set) var user: User?

    private var handle: AuthStateDidChangeListenerHandle?

    init() {
        // Listener de Firebase: se dispara en login, logout y arranque
        handle = Auth.auth().addStateDidChangeListener { _, user in
            self.user = user
        }
    }

    deinit {
        if let h = handle { Auth.auth().removeStateDidChangeListener(h) }
    }

    var isSignedIn: Bool { user != nil }
    
    /// Cierra la sesión actual; en caso de error muestra un alert simple.
    func signOut() {
        do {
            try Auth.auth().signOut()
        } catch {
            // Puedes sustituir print por un mecanismo de alert global.
            print("No se pudo cerrar sesión:", error.localizedDescription)
        }
    }
}
