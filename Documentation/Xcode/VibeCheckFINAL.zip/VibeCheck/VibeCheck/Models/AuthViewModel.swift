//
//  AuthViewModel.swift
//  VibeCheck
//
//  Created by Aldo Serrano Rugerio on 29/04/25.
//

import FirebaseAuth
import SwiftUI

@MainActor
class AuthViewModel: ObservableObject {
    @Published var email = ""
    @Published var password = ""
    @Published var isLoading = false
    @Published var errorMessage: String?

    func signInWithEmail() async {
        guard !email.isEmpty, !password.isEmpty else {
            errorMessage = "You must provide an email and a password."
            return
        }
        isLoading = true
        defer { isLoading = false }
        do {
            try await Auth.auth().signIn(withEmail: email, password: password)
            // Change view or app state
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    // Stubs para Google y Apple (se implementarían después)
    func signInWithGoogle() { /* TODO */ }
    func signInWithApple()  { /* TODO */ }
}
