//
//  HomeViewModel.swift
//  VibeCheck
//
//  Created by Aldo Serrano Rugerio on 05/05/25.
//


import Foundation

@MainActor
final class HomeViewModel: ObservableObject {
    /// Aquí guardamos las tres sugerencias: clearer, kinder y joyful
    @Published var suggestions: [String] = []
    @Published var isLoading  = false
    @Published var errorMessage: String?

    private let ai = AISuggestionService()

    func requestAll(for text: String) {
        isLoading = true
        suggestions = []
        errorMessage = nil

        Task {
            print("   ↪️ [VM] inside Task, launching calls")
            do {
                let clearer = try await ai.suggest(text: text, style: .clearer)
                let kinder  = try await ai.suggest(text: text, style: .kinder)
                let joyful  = try await ai.suggest(text: text, style: .joyful)
                suggestions = [clearer, kinder, joyful]
            } catch {
                errorMessage = error.localizedDescription
            }
            isLoading = false
        }
    }
}
