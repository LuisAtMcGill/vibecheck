//
//  ProfileViewModel.swift
//  VibeCheck
//
//  Created by Aldo Serrano Rugerio on 05/05/25.
//

import SwiftUI
import FirebaseFirestore
import FirebaseAuth

@MainActor
final class ProfileViewModel: ObservableObject {
    @Published var fullName = ""
    @Published var email    = ""

    init() { Task { await load() } }

    private func load() async {
        guard let user = Auth.auth().currentUser else { return }
        email = user.email ?? ""

        // Intentamos primero displayName
        if let dn = user.displayName, !dn.isEmpty {
            fullName = dn
            return
        }

        // Si no hay displayName buscamos en Firestore
        let doc = try? await Firestore.firestore()
                      .collection("users").document(user.uid).getDocument()

        if let nameFromDB = doc?.get("fullName") as? String {
            fullName = nameFromDB
        }
    }
}
