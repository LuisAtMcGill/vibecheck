//
//  UserInfoView.swift
//  VibeCheck
//
//  Created by Cecilia Soriano  on 30/04/25.
//

import SwiftUI

struct UserInfoView: View {
    @State private var firstName: String = ""
    @State private var lastName: String = ""

    var body: some View {
        ZStack {
            Color(.sRGB, red: 0/255, green: 17/255, blue: 58/255, opacity: 1.0)
                .ignoresSafeArea()

            VStack(spacing: 20) {
                Text("Your Information")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(Color.yellow)
                    .padding(.bottom,20)

                VStack(alignment: .leading, spacing: 12) {
                    Text("First Name")
                        .foregroundColor(.white)
                        .font(.headline)

                    TextField("Enter your first name", text: $firstName)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)

                    Text("Last Name")
                        .foregroundColor(.white)
                        .font(.headline)

                    TextField("Enter your last name", text: $lastName)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)
                }
                .padding(.horizontal)

                Button(action: {
                    // Acción al continuar
                }) {
                    Text("Sign Up")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.yellow)
                        .foregroundColor(.black)
                        .cornerRadius(10)
                }
                .padding(.horizontal)
            }
            .padding()
        }
    }
}

#Preview {
    UserInfoView()
}

