//
//  ProfileView.swift
//  VibeCheck
//
//  Created by Cecilia Soriano  on 16/03/25.
//

import SwiftUI

import SwiftUI

struct ProfileView: View {
    // Objeto globar para trackear el status del usuario
    @EnvironmentObject private var auth: AuthStore
    // Modelo para el perfil
    @StateObject private var vm = ProfileViewModel()
    
    var body: some View {
        ZStack {
            // Fondo azul completo
            Color(red: 0/255, green: 17/255, blue: 58/255)
                .ignoresSafeArea()

            VStack {
                Spacer().frame(height: 30) // Espacio visible superior azul
                VStack(spacing: 12) {
                    Image(systemName: "person.crop.circle.fill")
                        .resizable()
                        .frame(width: 80, height: 80)
                        .foregroundColor(.white)
                    Text(vm.fullName)
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.bottom,20)
                }
                .padding(.top, 20)

                // Contenedor blanco con esquinas redondeadas superiores
                VStack() {
                    // Imagen de perfil y nombre
                    
                    // Tarjetas
                    ForEach(0..<4, id: \.self) { _ in
                        SaveCardView()
                            .padding(.top,30)
                    }

                    // Botón cerrar sesión
                    Button(action: {
                        auth.signOut()
                    }) {
                        Text("Log out")
                            .fontWeight(.semibold)
                            .padding()
                            .foregroundColor(.red)
                    }
                    .padding(.top, 20)

                    Spacer()
                }
                .padding()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.white)
                .cornerRadius(30, corners: [.topLeft, .topRight])
            }
        }
    }
}

// Tarjeta
struct SaveCardView: View {
    var body: some View {
        HStack {
            Text("Scholar petition")
                .font(.body)
                .bold()
                .foregroundColor(.black)

            Spacer()

            Image(systemName: "bookmark.fill")
                .resizable()
                .frame(width: 20, height: 20)
                .foregroundColor(.yellow)
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color.gray.opacity(0.2), radius: 5, x: 0, y: 2)
    }
}

// Extensión para esquinas específicas
extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCornersShape(cornerRadius: radius, corners: corners))
    }
}

struct RoundedCornersShape: Shape {
    var cornerRadius: CGFloat
    var corners: UIRectCorner

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(
            roundedRect: rect,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: cornerRadius, height: cornerRadius)
        )
        return Path(path.cgPath)
    }
}

#Preview {
    ProfileView()
        .environmentObject(AuthStore())
}
