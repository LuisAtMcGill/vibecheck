//
//  RecommendationsBirthdayView.swift
//  VibeCheck
//
//  Created by Cecilia Soriano  on 20/03/25.
//
import SwiftUI
import FirebaseAuth
import FirebaseFirestore

// Modelo para los documentos
struct BirthdayMessage: Identifiable, Codable {
    @DocumentID var id: String?
    var text:     String
    var rating:   Int
    var ownerId:  String
}

struct RecommendationsBirthdayView: View {
    @State private var messages: [BirthdayMessage] = []
    @State private var errorMessage: String?
    private let db = Firestore.firestore()

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            // Título
            HStack {
                Text("Birthday messages")
                    .font(.title3)
                    .bold()
                Spacer()
            }
            .padding(.horizontal)

            // Lista de tarjetas
            ScrollView {
                VStack(spacing: 12) {
                    // La primera tarjeta abre SaveTextView
                    NavigationLink(destination: SaveTextView()) {
                        TaskCard(
                            icon:     "birthday.cake.fill",
                            author:   Auth.auth().currentUser?.displayName ?? "Me",
                            title:    "New message…",
                            progress: 0,
                            total:    5,
                            color:    Color.pink.opacity(0.2)
                        )
                    }
                    .buttonStyle(PlainButtonStyle())

                    // Una tarjeta por cada mensaje del usuario
                    ForEach(messages) { msg in
                        TaskCard(
                            icon:     "birthday.cake.fill",
                            author:   Auth.auth().currentUser?.displayName ?? "Me",
                            title:    msg.text,
                            progress: msg.rating,
                            total:    5,
                            color:    Color.blue.opacity(0.2)
                        )
                    }
                }
                .padding(.horizontal)
            }
        }
        .onAppear(perform: subscribe)
        .alert("Error", isPresented: Binding(
            get: { errorMessage != nil },
            set: { _ in errorMessage = nil }
        )) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(errorMessage ?? "")
        }
    }

    /// Suscribe a los mensajes del usuario actual
    private func subscribe() {
        guard let uid = Auth.auth().currentUser?.uid else {
            errorMessage = "Usuario no autenticado"
            return
        }
        db.collection("birthdayMessages")
            .whereField("ownerId", isEqualTo: uid)
            .order(by: "created", descending: true)
            .addSnapshotListener { snap, err in
                if let err = err {
                    errorMessage = err.localizedDescription
                    return
                }
                messages = snap?.documents.compactMap { doc in
                    try? doc.data(as: BirthdayMessage.self)
                } ?? []
            }
    }
}

// Tu TaskCard original
struct TaskCard: View {
    let icon: String
    let author: String
    let title: String
    let progress: Int
    let total: Int
    let color: Color

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(color)
                    .frame(width: 50, height: 50)
                Image(systemName: icon)
                    .foregroundColor(.blue)
                    .font(.system(size: 22))
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.body)
                Text(author)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                StarRatingView(rating: progress, total: total)
            }
            Spacer()
        }
        .padding()
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color.gray.opacity(0.2), radius: 4, x: 0, y: 2)
    }
}

// Tu StarRatingView original
struct StarRatingView: View {
    let rating: Int
    let total: Int

    var body: some View {
        HStack(spacing: 4) {
            ForEach(0..<total, id: \.self) { index in
                Image(systemName: index < rating ? "star.fill" : "star")
                    .foregroundColor(index < rating ? .yellow : .gray.opacity(0.5))
                    .font(.system(size: 16))
            }
        }
    }
}

#Preview {
    RecommendationsBirthdayView()
}
