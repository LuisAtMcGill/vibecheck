//
//  ContentView.swift
//  VibeCheck
//
//  Created by Cecilia Soriano  on 06/03/25.
//

import SwiftUI

struct ContentView: View {
    @State private var isActive = false
    @EnvironmentObject private var auth: AuthStore

    var body: some View {
        Group {
            if auth.isSignedIn {
                ZStack {
                    Color(red: 0/255, green: 17/255, blue: 58/255)
                        .edgesIgnoringSafeArea(.all)
                    
                    Text("VibeCheck")
                        .font(.system(size: 40, weight: .black))
                        .foregroundColor(Color(red: 255/255, green: 219/255, blue: 39/255))
                }
                .onAppear {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                        isActive = true
                    }
                }
                .fullScreenCover(isPresented: $isActive) {
                    MainTabView()
                }
            }
            else {
                LoginView()
            }
        }
    }
}

#Preview {
    ContentView()
        .environmentObject(AuthStore())
}
