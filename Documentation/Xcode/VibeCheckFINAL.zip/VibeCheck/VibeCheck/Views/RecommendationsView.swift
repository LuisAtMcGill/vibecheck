//
//  RecommendationsView.swift
//  VibeCheck
//
//  Created by Cecilia Soriano  on 27/03/25.
//

import SwiftUI

struct RecommendationsView: View {
    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                // Título
                Text("Vibe recommendations")
                    .font(.title2)
                    .bold()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal)

                // Barra de búsqueda
                SearchBar()

                // Sección "Most popular"
                VStack(alignment: .leading, spacing: 8) {
                    Text("Most popular")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                        .padding(.horizontal)

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 16) {
                            NavigationLink(destination: RecommendationsBirthdayView()) {
                                PopularCard(title: "Birthday messages", color: .yellow, icon: "birthday.cake.fill")
                            }
                            .buttonStyle(PlainButtonStyle())
                            PopularCard(title: "English essay", color: .red, icon: "book.fill")
                            PopularCard(title: "Quotes", color: .blue, icon: "pencil")
                        }
                        .padding(.horizontal)
                    }
                }

                // Sección "Search by mood"
                VStack(alignment: .leading, spacing: 8) {
                    Text("Search by mood")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                        .padding(.horizontal)

                    VStack(spacing: 12) {
                        MoodRow(mood: "Happy", color: .yellow)
                        MoodRow(mood: "Angry", color: .red)
                        MoodRow(mood: "Sad", color: .blue)
                    }
                    .padding(.horizontal)
                }

                Spacer()
            }
            .padding(.top)
        }
    }
}

// Barra de búsqueda
struct SearchBar: View {
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.gray)

            Text("Search vibes")
                .foregroundColor(.gray)

            Spacer()
        }
        .padding()
        .background(Color.gray.opacity(0.15))
        .cornerRadius(10)
        .padding(.horizontal)
    }
}

// Tarjetas "Most popular"
struct PopularCard: View {
    let title: String
    let color: Color
    let icon: String

    var body: some View {
        VStack(spacing: 8) {
            Spacer()

            Image(systemName: icon)
                .resizable()
                .scaledToFit()
                .frame(width: 40, height: 40)
                .foregroundColor(.white)

            Text(title)
                .font(.headline)
                .foregroundColor(.white)
                .multilineTextAlignment(.center)

            Spacer()
        }
        .frame(width: 120, height: 140)
        .padding()
        .background(color)
        .cornerRadius(16)
    }
}

struct MoodRow: View {
    let mood: String
    let color: Color

    var body: some View {
        HStack {
            Text(mood)
                .font(.body)
                .foregroundColor(.black)

            Spacer()

            Circle()
                .fill(color)
                .frame(width: 50, height: 50)
                .overlay(
                    HStack {
                        Circle()
                            .fill(.black)
                            .frame(width: 8, height: 8)
                        Circle()
                            .fill(.black)
                            .frame(width: 8, height: 8)
                    }
                )
                .offset(x: 10, y: 30)
        }
        .padding()
        .background(Color.gray.opacity(0.3))
        .cornerRadius(12)
    }
}

#Preview {
    RecommendationsView()
}
