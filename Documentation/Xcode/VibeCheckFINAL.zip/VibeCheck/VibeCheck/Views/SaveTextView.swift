//
//  SaveTextView.swift
//  VibeCheck
//
//  Created by Cecilia Soriano on 20/03/25.
//

// SaveTextView.swift
// VibeCheck

import SwiftUI

struct SaveTextView: View {
    private static let defaultMessage = """
    Espero que tengas un día increíble, \
    lleno de alegría, risas y muchas sorpresas. \
    Eres una persona increíble, y me alegra muchísimo tenerte en mi vida. \
    Disfruta cada momento, come mucho pastel 🎂 y celebra a lo grande. \
    ¡Te mereces lo mejor hoy y siempre! 🎁🎈🎊
    """

    @StateObject private var vm = SaveTextViewModel(initialMessage: defaultMessage)
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // Encabezado
                    Text("For my BFF")
                        .font(.title).bold()
                        .foregroundColor(.secondary)
                    Text("Kitzia")
                        .foregroundColor(.gray)

                    // Estrellas con rating actual
                    StarRatingView(rating: vm.rating, total: 5)
                        .font(.largeTitle)

                    // Editor de texto
                    TextEditor(text: $vm.message)
                        .frame(minHeight: 200)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.gray.opacity(0.5), lineWidth: 1)
                        )
                        .padding(.horizontal)

                    // Error en rating
                    if let error = vm.errorMessage {
                        Text(error)
                            .foregroundColor(.red)
                            .font(.caption)
                    }

                    // Botón exclusivo para solicitar el rating
                    if vm.isLoading {
                        ProgressView("Rating…")
                    } else {
                        Button("Rate Message") {
                            Task {
                                do {
                                    try await vm.rateMessage()
                                } catch {
                                    vm.errorMessage = error.localizedDescription
                                }
                            }
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(vm.message.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    }

                    Spacer()
                }
                .padding()
            }
            .navigationTitle("New Birthday Msg")
            .toolbar {
                // Cancelar sin guardar
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                // Done guarda y cierra
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") {
                        Task {
                            do {
                                try await vm.saveMessage()
                                dismiss()
                            } catch {
                                vm.errorMessage = error.localizedDescription
                            }
                        }
                    }
                    .disabled(vm.isLoading)
                }
            }
        }
    }
}

#Preview {
    SaveTextView()
}
