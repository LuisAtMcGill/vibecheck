//
//  LoginView.swift
//  VibeCheck
//
//  Created by Cecilia Soriano  on 27/03/25.
//

import SwiftUI

struct LoginView: View {
    @StateObject private var vm = AuthViewModel()
    @State private var isPasswordVisible = false

    var body: some View {
        NavigationView {
            ZStack {
                Color(red: 0/255, green: 17/255, blue: 58/255).ignoresSafeArea()

                VStack {
                    Spacer()

                    Text("Login")
                        .font(.largeTitle)
                        .bold()
                        .foregroundColor(Color(red: 255/255, green: 219/255, blue: 39/255))
                        .padding(.bottom, 20)

                    //––– Campos de texto
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Email")
                            .font(.headline)
                            .foregroundColor(.white)

                        TextField("nombre@dominio.com", text: $vm.email)
                            .textInputAutocapitalization(.never)
                            .keyboardType(.emailAddress)
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(10)

                        Text("Password")
                            .font(.headline)
                            .foregroundColor(.white)

                        HStack {
                            if isPasswordVisible {
                                TextField("••••••••", text: $vm.password)
                            } else {
                                SecureField("••••••••", text: $vm.password)
                            }
                            Button {
                                isPasswordVisible.toggle()
                            } label: {
                                Image(systemName: isPasswordVisible ? "eye.slash.fill" : "eye.fill")
                                    .foregroundColor(.gray)
                            }
                        }
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)

                        if let error = vm.errorMessage {
                            Text(error)
                                .foregroundColor(.red)
                                .font(.caption)
                        }
                    }
                    .padding(.horizontal)

                    //––– Botón principal
                    Button {
                        Task { await vm.signInWithEmail() }
                    } label: {
                        if vm.isLoading {
                            ProgressView()
                                .progressViewStyle(.circular)
                                .tint(Color(red: 0/255, green: 17/255, blue: 58/255))
                                .frame(maxWidth: .infinity)
                                .padding()
                        } else {
                            Text("Login")
                                .frame(maxWidth: .infinity)
                                .padding()
                        }
                    }
                    .background(Color(red: 255/255, green: 219/255, blue: 39/255))
                    .foregroundColor(Color(red: 0/255, green: 17/255, blue: 58/255))
                    .cornerRadius(10)
                    .padding(.horizontal)
                    .padding(.top)

                    //––– Placeholders para Google y Apple
                    VStack(spacing: 12) {
                        Button { vm.signInWithGoogle() } label: {
                            HStack {
                                Image(systemName: "globe")
                                Text("Continue with Google")
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.white)
                            .foregroundColor(.black)
                            .cornerRadius(10)
                        }
                        Button { vm.signInWithApple() } label: {
                            HStack {
                                Image(systemName: "applelogo")
                                Text("Continue with Apple")
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.white)
                            .foregroundColor(.black)
                            .cornerRadius(10)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.top, 10)

                    Spacer()

                    NavigationLink("Don't have an account? Sign up", destination: SignUpView())
                        .foregroundColor(.white)
                        .font(.caption)

                    Spacer()
                }
                .padding()
            }
        }
    }
}

#Preview {
    LoginView()
}
