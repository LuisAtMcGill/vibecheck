//
//  HomeView.swift
//  VibeCheck
//
//  Created by Cecilia Soriano  on 27/03/25.
//


import SwiftUI

struct HomeView: View {
    // Highlighed texts
    @State private var highlightedText1 = "Process suggestions"
    @State private var highlightedText2 = "Process suggestions"
    @State private var highlightedText3 = "Process suggestions"
    
    // Original texts
    @State private var Text1 = "I’d love to treat you to dinner! Let’s grab a meal together and enjoy some quality time. How about this friday at Carl's Jr? My treat just your company is all I need."
    @State private var Text2 = "Congrats, graduate! All your hard work paid off—this is just the beginning of something amazing. So proud of you and excited to see where your journey takes you next! Let’s celebrate soon!"
    @State private var Text3 = "Hope you’re well! I’d like to discuss the Project Plan to ensure we’re aligned on next steps and priorities. Could we schedule a brief chat this week? Let me know a time that works for you."

    // Para el pop-up
    @State private var showPopup = false
    @State private var selectedWord: Binding<String>? = nil

    @StateObject private var vm = HomeViewModel()

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {

                    Text(":)")
                        .font(.title).bold().foregroundColor(.gray)
                        .padding(.leading)

                    Divider()

                    HStack {
                        TagView(text: "Fun")
                        TagView(text: "Joy")
                        TagView(text: "Kindness")
                    }
                    .padding(.bottom, 10)
                    .padding(.leading)

                    Group {
                        Text(Text1)

                        Text(highlightedText1)
                            .foregroundColor(.black)
                            .background(Color.yellow.opacity(0.5))
                            .onTapGesture {
                                selectedWord = $highlightedText1
                                showPopup = true
                                vm.requestAll(for: Text1)
                            }

                        Text(Text2)

                        Text(highlightedText2)
                            .foregroundColor(.white)
                            .background(Color.green.opacity(0.8))
                            .cornerRadius(5)
                            .onTapGesture {
                                selectedWord = $highlightedText2
                                showPopup = true
                                vm.requestAll(for: Text2)
                            }

                        Text(Text3)

                        Text(highlightedText3)
                            .foregroundColor(.white)
                            .background(Color.red.opacity(0.7))
                            .cornerRadius(5)
                            .onTapGesture {
                                selectedWord = $highlightedText3
                                showPopup = true
                                vm.requestAll(for: Text3)
                            }
                    }
                    .font(.system(size: 18))
                    .padding(.horizontal)
                }
            }
            .navigationTitle("Home")
        }
        // Pop-up overlay
        .overlay(
            Group {
                if showPopup {
                    Color.black.opacity(0.3)
                        .ignoresSafeArea()
                        .onTapGesture { showPopup = false }

                    VStack(spacing: 15) {
                        HStack {
                            Image(systemName: "bubble.left.fill")
                                .font(.title)
                                .foregroundColor(.blue)
                            Spacer()
                        }

                        Text("Choose a suggestion:")
                            .font(.headline)

                        if vm.isLoading {
                            ProgressView("Generating…")
                                .padding()
                        }
                        else if let error = vm.errorMessage {
                            Text(error)
                                .foregroundColor(.red)
                                .font(.caption)
                        }
                        else {
                            ForEach(Array(vm.suggestions.enumerated()), id: \.offset) { _, suggestion in
                                Button {
                                    if let binding = selectedWord {
                                        binding.wrappedValue = suggestion
                                    }
                                    showPopup = false
                                } label: {
                                    Text(suggestion)
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(Color.blue.opacity(0.1))
                                        .foregroundColor(.blue)
                                        .cornerRadius(8)
                                }
                            }
                        }

                        Button("Cancel") {
                            showPopup = false
                        }
                        .bold()
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.gray.opacity(0.5))
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    .frame(width: 300)
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    .shadow(radius: 10)
                }
            }
        )
    }
}

// Componente auxiliar de etiqueta
struct TagView: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.caption).bold()
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(Color(red: 0/255, green: 17/255, blue: 58/255))
            .foregroundColor(.white)
            .cornerRadius(10)
    }
}

#Preview {
    HomeView()
}
