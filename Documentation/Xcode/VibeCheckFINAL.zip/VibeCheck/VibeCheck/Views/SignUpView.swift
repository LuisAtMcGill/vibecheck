//
//  SiginView.swift
//  VibeCheck
//
//  Created by Cecilia Soriano  on 27/03/25.
//

import SwiftUI
import AuthenticationServices

struct SignUpView: View {
    @StateObject private var vm = SignUpViewModel()

    @State private var showPassword = false
    @State private var showConfirm  = false
    

    var body: some View {
        ZStack {
            Color(red: 0/255, green: 17/255, blue: 58/255).ignoresSafeArea()

            VStack {
                Spacer()

                Text("Sign Up")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(Color(red: 255/255, green: 219/255, blue: 39/255))
                    .padding(.bottom, 20)

                formFields
                    .padding(.horizontal)

                mainButton
                    .padding()

                thirdPartyButtons
                    .padding(.horizontal)

                if let error = vm.errorMessage {
                    Text(error).foregroundColor(.red).font(.caption)
                }

                Spacer()

                NavigationLink("Already have an account? Login here",
                               destination: LoginView())
                    .foregroundColor(.white)
                    .font(.caption)

                Spacer()
            }
            .padding()
        }
    }

    // MARK: – Subvistas

    private var formFields: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Email").font(.headline).foregroundColor(.white)
            TextField("name@domain.com", text: $vm.email)
                .keyboardType(.emailAddress)
                .textInputAutocapitalization(.never)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(10)
            
            Text("First and Last Name")
                .foregroundColor(.white)
                .font(.headline)
            TextField("Enter your first and last name", text: $vm.name)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(10)

            Text("Password").font(.headline).foregroundColor(.white)
            passwordField(text: $vm.password, visible: $showPassword)

            Text("Confirm Password").font(.headline).foregroundColor(.white)
            passwordField(text: $vm.confirm, visible: $showConfirm)
        }
    }

    private func passwordField(text: Binding<String>, visible: Binding<Bool>) -> some View {
        HStack {
            Group {
                if visible.wrappedValue {
                    TextField("", text: text)
                } else {
                    SecureField("", text: text)
                }
            }.padding()

            Button { visible.wrappedValue.toggle() } label: {
                Image(systemName: visible.wrappedValue ? "eye.slash" : "eye")
                    .foregroundColor(.gray)
            }.padding(.trailing, 8)
        }
        .background(Color(.systemGray6))
        .cornerRadius(10)
    }

    private var mainButton: some View {
        Button {
            Task { await vm.createAccount() }
        } label: {
            Group {
                if vm.isLoading {
                            ProgressView().progressViewStyle(.circular)
                                .frame(maxWidth: .infinity).padding()
                }
                else {
                    Text("Sign Up")
                }
            }
            .frame(maxWidth: .infinity)
            .padding()
        }
        .background(Color(red: 255/255, green: 219/255, blue: 39/255))
        .foregroundColor(Color(red: 0/255, green: 17/255, blue: 58/255))
        .cornerRadius(10)
    }

    private var thirdPartyButtons: some View {
        VStack(spacing: 12) {
            Button {
                Task { await vm.signUpWithGoogle() }
            } label: {
                HStack {
                    Image(systemName: "globe")
                    Text("Sign in with Google").fontWeight(.medium)
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.white)
                .foregroundColor(.black)
                .cornerRadius(10)
            }

            SignInWithAppleButton(
                onRequest: { request in
                    request.requestedScopes = [.fullName, .email]
                },
                onCompletion: { result in
                    switch result {
                    case .success(let authorization):
                        // Intentamos extraer el credential concreto
                        if let cred = authorization.credential as? ASAuthorizationAppleIDCredential {
                            Task { await vm.signUpWithApple(credential: cred) }
                        }
                    case .failure(let error):
                        vm.errorMessage = error.localizedDescription
                    }
                }
            )
            .signInWithAppleButtonStyle(.white)
            .frame(height: 45)
            .cornerRadius(10)
        }
    }
}

#Preview {
    SignUpView()
}
