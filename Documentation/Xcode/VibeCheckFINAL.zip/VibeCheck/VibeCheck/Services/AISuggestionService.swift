//
//  AISuggestionService.swift
//  VibeCheck
//
//  Created by Aldo Serrano Rugerio on 05/05/25.
//
//  Genera la reescritura usando el modelo "llama-3.3-70b-versatile"
//  servido por Groq Cloud
//

import Foundation

// ──────────────────────────────────────────────────────────
// MARK: - Tonos de reescritura
// ──────────────────────────────────────────────────────────

enum SuggestionStyle: String, CaseIterable, Identifiable {
    case clearer = "Clearer"
    case kinder  = "Kinder"
    case joyful  = "Joyful"

    var id: String { rawValue }

    /// Prompt que describe la transformación deseada
    var prompt: String {
        switch self {
        case .clearer:
            return "Rewrite the following text in a clearer and more straightforward way, without changing its meaning, just give me the new text:"
        case .kinder:
            return "Rewrite the following text in a kinder and gentler way, without changing its meaning, just give me the new text:"
        case .joyful:
            return "Rewrite the following text in a joyful and happy way, without changing its meaning, just give me the new text:"
        }
    }
}

// ──────────────────────────────────────────────────────────
// MARK: - Servicio de IA
// ──────────────────────────────────────────────────────────

struct AISuggestionService {

    // 1. Obtiene la clave desde Info.plist (inyectada por Secrets.xcconfig)
    private let token: String = {
        Bundle.main.object(forInfoDictionaryKey: "GROQ_API_KEY") as? String ?? ""
    }()
    

    // 2. Constantes de Groq
    private let endpoint = URL(string: "https://api.groq.com/openai/v1/chat/completions")!
    private let model    = "llama-3.3-70b-versatile"
    

    // Sesión global sin HTTP/3
    static let session: URLSession = { 
        let cfg = URLSessionConfiguration.default
        cfg.waitsForConnectivity = true
        return URLSession(configuration: cfg)
    }()

    // 4. Errores propios
    enum AIError: LocalizedError {
        case emptyToken, emptyResponse
        var errorDescription: String? {
            switch self {
            case .emptyToken   : return "Token de Groq vacío o no configurado."
            case .emptyResponse: return "El modelo devolvió una respuesta vacía."
            }
        }
    }

    // 5. Método principal
    func suggest(text: String, style: SuggestionStyle) async throws -> String {
        guard !token.isEmpty else { throw AIError.emptyToken }
        
        #if DEBUG
        print("[AI] token prefix:", token.prefix(8))
        #endif

        // Construye la petición HTTP
        var req = URLRequest(url: endpoint)
        req.httpMethod = "POST"
        req.addValue("application/json", forHTTPHeaderField: "Content-Type")
        req.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        req.setValue("close", forHTTPHeaderField: "Connection")

        // Cuerpo JSON (idéntico a tu cURL)
        let body: [String: Any] = [
            "model": model,
            "messages": [
                [
                    "role": "user",
                    "content": "\(style.prompt)\n\n\(text)"
                ]
            ],
            "temperature": 0.7,
            "max_tokens": 120
        ]
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let rawBody = try JSONSerialization.data(withJSONObject: body, options: .prettyPrinted)
                req.httpBody = rawBody

        #if DEBUG
        print("[AI] Request JSON:", String(data: rawBody, encoding: .utf8)!)
        #endif

        // Llamada con reintento simple en -1005 / -1001 / -1009
        let (data, http) = try await fetchWithRetry(request: req, retries: 2)

        #if DEBUG
        print("[AI] HTTP:", http.statusCode)
        print("[AI] Raw JSON:", String(data: data, encoding: .utf8) ?? "nil")
        #endif

        // Parseo del JSON
        let json = try JSONSerialization.jsonObject(with: data) as? [String: Any]
        if
            let choices = json?["choices"] as? [[String: Any]],
            let msg = choices.first?["message"] as? [String: Any],
            let content = msg["content"] as? String
        {
            return content.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        throw AIError.emptyResponse
    }
}

extension AISuggestionService {
    func rateMessage(_ text: String) async throws -> Int {
        guard !token.isEmpty else {
            throw AIError.emptyToken
        }

        // Prompt claro
        let systemPrompt =
        """
        You are an assistant that rates user-written social messages from 1 to 5 stars.
        Consider writing quality, coherence, topic and tone (if happy, must sound happy).
        Respond with a single integer between 1 and 5, and nothing else.
        """
        let userPrompt = text

        // Construye petición idéntica a tu curl
        var req = URLRequest(url: endpoint)
        req.httpMethod = "POST"
        req.addValue("application/json", forHTTPHeaderField: "Content-Type")
        req.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        req.setValue("close", forHTTPHeaderField: "Connection")

        let payload: [String:Any] = [
            "model": model,
            "messages": [
                ["role":"system", "content": systemPrompt],
                ["role":"user",   "content": userPrompt]
            ],
            "temperature": 0.0,
            "max_tokens": 5
        ]
        req.httpBody = try JSONSerialization.data(withJSONObject: payload)

        // Llamada
        let (data, http) = try await fetchWithRetry(request: req, retries: 2)

        #if DEBUG
        print("[AI rate] HTTP", http.statusCode)
        print("[AI rate] raw:", String(data: data, encoding: .utf8) ?? "nil")
        #endif

        // EXTRAEMOS SOLO EL content del JSON
        let obj = try JSONSerialization.jsonObject(with: data) as? [String:Any]
        guard
            let choices = obj?["choices"] as? [[String:Any]],
            let msg = (choices.first?["message"] as? [String:Any])?["content"] as? String
        else {
            throw NSError(domain: "AISuggestionService",
                          code: 0,
                          userInfo: [NSLocalizedDescriptionKey: "JSON no contiene choices[0].message.content"])
        }

        // AHORA SÍ, extracción robusta del dígito
        let cleaned = msg.trimmingCharacters(in: .whitespacesAndNewlines)
        if let range = cleaned.range(of: #"(\d+)"#, options: .regularExpression) {
            let num = String(cleaned[range])
            if let stars = Int(num), (1...5).contains(stars) {
                return stars
            }
        }

        throw NSError(domain: "AISuggestionService",
                      code: 0,
                      userInfo: [NSLocalizedDescriptionKey: "Could not parse rating from '\(msg)'"])
    }
}

// ──────────────────────────────────────────────────────────
// MARK: - Helper de reintento
// ──────────────────────────────────────────────────────────

/// Errores transitorios que merece la pena reintentar.
private let transientCodes: Set<URLError.Code> = [
    .networkConnectionLost,   // -1005
    .timedOut,                // -1001
    .notConnectedToInternet   // -1009
]

/// Sesión global con espera por conectividad, usando HTTP/1.1 o HTTP/2 según el sistema.
private let legacySession: URLSession = {
    let cfg = URLSessionConfiguration.default
    cfg.waitsForConnectivity = true
    // Si en el futuro migras a iOS 17+, aquí podrías reactivar HTTP/3Support
    return URLSession(configuration: cfg)
}()

/// Petición con hasta `retries` reintentos en errores transitorios.
/// Devuelve (Data, HTTPURLResponse) para poder inspeccionar el status.
func fetchWithRetry(request: URLRequest,
                    retries: Int = 2,
                    delay: UInt64 = 1_000_000_000 /* 1 s */) async throws -> (Data, HTTPURLResponse) {
    print("🛠 fetchWithRetry START →", request.url?.absoluteString ?? "no-url")
    var lastError: Error?

    for attempt in 0...retries {
        print("  🔁 Attempt \(attempt) ...")
        do {
            let (data, resp) = try await legacySession.data(for: request)
            guard let http = resp as? HTTPURLResponse else {
                print("  ⚠️ No HTTPURLResponse, aborting")
                throw URLError(.badServerResponse)
            }
            print("  ✅ Attempt \(attempt) → HTTP", http.statusCode, "(\(data.count) bytes)")
            return (data, http)
        } catch {
            lastError = error
            print("  🛑 Attempt \(attempt) ERROR:", error)
            // Solo reintentar si es un error transitorio y quedan retries
            if let urlErr = error as? URLError,
               transientCodes.contains(urlErr.code),
               attempt < retries {
                print("    ↩️ Transient \(urlErr.code). Retrying in 1 s…")
                try? await Task.sleep(nanoseconds: delay)
                continue
            }
            print("    ❌ No more retries, throwing error")
            throw error
        }
    }
    print("⚠️ Exiting loop, throwing lastError:", lastError ?? "nil")
    throw lastError ?? URLError(.cannotLoadFromNetwork)
}
