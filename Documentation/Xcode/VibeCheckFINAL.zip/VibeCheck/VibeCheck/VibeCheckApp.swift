//
//  VibeCheckApp.swift
//  VibeCheck
//
//  Created by Cecilia Soriano  on 06/03/25.
//

import SwiftUI
import Firebase

import UIKit

extension UIApplication {
    /// Primera keyWindow compatible con iOS 13+
    var firstKeyWindow: UIWindow? {
        connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .first { $0.isKeyWindow }
    }
}

@main
struct VibeCheckApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @StateObject private var auth = AuthStore()
    var body: some Scene {
        WindowGroup {
                    ContentView()            // ← Vista raiz
                        .environmentObject(auth)
                }
    }
}

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil
    ) -> Bool {
        FirebaseApp.configure()
        return true
    }
}
