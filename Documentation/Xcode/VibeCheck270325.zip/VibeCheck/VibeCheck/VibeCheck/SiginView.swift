//
//  SiginView.swift
//  VibeCheck
//
//  Created by Cecilia Soriano  on 27/03/25.
//

import SwiftUI

struct SignUpView: View {
    @State private var username: String = ""
    @State private var password: String = ""
    @State private var confirmPassword: String = ""

    var body: some View {
        VStack {
            Spacer()
            
            Text("Sign Up")
                .font(.largeTitle)
                .bold()
                .padding(.bottom, 20)

            VStack(alignment: .leading, spacing: 10) {
                Text("User name")
                    .font(.headline)
                    .foregroundColor(.gray)
                
                TextField("Enter your username", text: $username)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)

                Text("Password")
                    .font(.headline)
                    .foregroundColor(.gray)
                
                SecureField("Enter your password", text: $password)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)

                Text("Confirm Password")
                    .font(.headline)
                    .foregroundColor(.gray)
                
                SecureField("Confirm your password", text: $confirmPassword)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
            }
            .padding(.horizontal)

            Button(action: {
                // Acción de registro
            }) {
                Text("Sign Up")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color(red: 0/255, green: 17/255, blue: 58/255))
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding()

            Spacer()
            
            NavigationLink(destination: LoginView()) {
                Text("Already have an account? Login here")
                    .foregroundColor(Color(red: 0/255, green: 17/255, blue: 58/255))
                    .font(.caption)
            }
            
            Spacer()
        }
        .padding()
    }
}

#Preview {
    SignUpView()
}

