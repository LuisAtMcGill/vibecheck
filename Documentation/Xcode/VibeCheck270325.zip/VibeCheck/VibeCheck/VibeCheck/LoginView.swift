//
//  LoginView.swift
//  VibeCheck
//
//  Created by Cecilia Soriano  on 27/03/25.
//
import SwiftUI

struct LoginView: View {
    @State private var username: String = ""
    @State private var password: String = ""

    var body: some View {
        NavigationView {
            VStack {
                Spacer()
                
                Text("Login")
                    .font(.largeTitle)
                    .bold()
                    .padding(.bottom, 20)

                VStack(alignment: .leading, spacing: 10) {
                    Text("User name")
                        .font(.headline)
                        .foregroundColor(.gray)
                    
                    TextField("Enter your username", text: $username)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)

                    Text("Password")
                        .font(.headline)
                        .foregroundColor(.gray)
                    
                    SecureField("Enter your password", text: $password)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)

                    HStack {
                        Spacer()
                        Button("Forgot Password?") { }
                            .foregroundColor(Color(red: 0/255, green: 17/255, blue: 58/255))
                            .font(.caption)
                    }
                }
                .padding(.horizontal)

                Button(action: {
                    // Acción de login
                }) {
                    Text("Login")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(red: 0/255, green: 17/255, blue: 58/255))
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding()

                Spacer()
                
                NavigationLink(destination: SignUpView()) {
                    Text("Don't have an account? Sign Up")
                        .foregroundColor(Color(red: 0/255, green: 17/255, blue: 58/255))
                        .font(.caption)
                }
                
                Spacer()
            }
            .padding()
        }
    }
}

#Preview {
    LoginView()
}
