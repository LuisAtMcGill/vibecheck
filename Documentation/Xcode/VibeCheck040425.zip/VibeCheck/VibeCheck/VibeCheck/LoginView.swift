import SwiftUI

struct LoginView: View {
    @State private var username: String = ""
    @State private var password: String = ""
    @State private var isPasswordVisible: Bool = false

    var body: some View {
        NavigationView {
            ZStack {
                Color(red: 0/255, green: 17/255, blue: 58/255) // #00113A
                    .ignoresSafeArea()

                VStack {
                    Spacer()

                    Text("Login")
                        .font(.largeTitle)
                        .bold()
                        .foregroundColor(Color(red: 255/255, green: 219/255, blue: 39/255)) // #FFDB27
                        .padding(.bottom, 20)

                    VStack(alignment: .leading, spacing: 10) {
                        Text("User name")
                            .font(.headline)
                            .foregroundColor(.white)

                        TextField("Enter your username", text: $username)
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(10)

                        Text("Password")
                            .font(.headline)
                            .foregroundColor(.white)

                        HStack {
                            Group {
                                if isPasswordVisible {
                                    TextField("Enter your password", text: $password)
                                } else {
                                    SecureField("Enter your password", text: $password)
                                }
                            }

                            Button(action: {
                                isPasswordVisible.toggle()
                            }) {
                                Image(systemName: isPasswordVisible ? "eye.slash.fill" : "eye.fill")
                                    .foregroundColor(.gray)
                            }
                        }
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)

                        HStack {
                            Spacer()
                            Button("Forgot Password?") { }
                                .foregroundColor(.white)
                                .font(.caption)
                        }
                    }
                    .padding(.horizontal)

                    Button(action: {
                        // Acción de login
                    }) {
                        Text("Login")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color(red: 255/255, green: 219/255, blue: 39/255)) // #FFDB27
                            .foregroundColor(Color(red: 0/255, green: 17/255, blue: 58/255)) // #00113A
                            .cornerRadius(10)
                    }
                    .padding(.horizontal)
                    .padding(.top)

                    // 🔐 Login con Apple y Google
                    VStack(spacing: 12) {
                        Button(action: {
                            // Acción Google
                        }) {
                            HStack {
                                Image(systemName: "globe") // Puedes usar un logo de Google si lo tienes
                                Text("Continue with Google")
                                    .fontWeight(.medium)
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.white)
                            .foregroundColor(.black)
                            .cornerRadius(10)
                        }

                        Button(action: {
                            // Acción Apple
                        }) {
                            HStack {
                                Image(systemName: "applelogo")
                                Text("Continue with Apple")
                                    .fontWeight(.medium)
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.white)
                            .foregroundColor(.black)
                            .cornerRadius(10)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.top, 10)

                    Spacer()

                    NavigationLink(destination: SignUpView()) {
                        Text("Don't have an account? Sign Up")
                            .foregroundColor(.white)
                            .font(.caption)
                    }

                    Spacer()
                }
                .padding()
            }
        }
    }
}

#Preview {
    LoginView()
}
