import SwiftUI

struct HomeView2: View {
    @State private var showPopup = false
    @State private var selectedWord: Binding<String>? = nil
    @State private var selectedReplacement = ""

    @State private var highlightedText1 = "incididunt ut labore et dolore magna aliqua."
    @State private var highlightedText2 = "commodo consequat."
    @State private var highlightedText3 = "qui officia deserunt"

    let replacementOptions = [
        "Texto Alternativo 1",
        "Texto Alternativo 2",
        "Texto Alternativo 3"
    ]

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    
                    Text("Title")
                        .font(.title)
                        .bold()
                        .foregroundColor(Color(red: 157/255, green: 155/255, blue: 155/255))
                    
                    Divider()
                    
                    HStack {
                        TagView(text: "scholar")
                        TagView(text: "petition")
                        TagView(text: "apologize")
                    }
                    .padding(.bottom, 10)
                    
                    Group {
                        Text("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ")
                        
                        Text(highlightedText1)
                            .foregroundColor(.black)
                            .background(Color.yellow.opacity(0.5))
                            .onTapGesture {
                                selectedWord = $highlightedText1
                                showPopup = true
                            }
                        
                        Text("Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea ")
                        
                        Text(highlightedText2)
                            .foregroundColor(.white)
                            .background(Color.green.opacity(0.8))
                            .cornerRadius(5)
                            .onTapGesture {
                                selectedWord = $highlightedText2
                                showPopup = true
                            }
                        
                        Text("Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa ")
                        
                        Text(highlightedText3)
                            .foregroundColor(.white)
                            .background(Color.red.opacity(0.7))
                            .cornerRadius(5)
                            .onTapGesture {
                                selectedWord = $highlightedText3
                                showPopup = true
                            }
                        
                        Text(" mollit anim id est laborum.")
                    }
                    .font(.system(size: 18))
                }
                .padding()
            }
        }
        
        .overlay(
            Group {
                if showPopup {
                    Color.black.opacity(0.3)
                        .edgesIgnoringSafeArea(.all)
                        .onTapGesture {
                            showPopup = false
                        }

                    VStack(spacing: 15) {
                        HStack {
                            Image(systemName: "bubble.left.fill")
                                .foregroundColor(.blue)
                                .font(.title)
                            Spacer()
                        }
                        
                        Text("Selecciona una opción:")
                            .font(.headline)
                            .padding(.bottom, 5)

                        // Opciones predefinidas
                        VStack(spacing: 10) {
                            ForEach(replacementOptions, id: \.self) { option in
                                Button(action: {
                                    if let selectedWord = selectedWord {
                                        selectedWord.wrappedValue = option // 🔹 Reemplaza el texto
                                    }
                                    showPopup = false
                                }) {
                                    Text(option)
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(Color.blue.opacity(0.1))
                                        .foregroundColor(.blue)
                                        .cornerRadius(8)
                                }
                            }
                        }
                        
                        Button(action: {
                            showPopup = false
                        }) {
                            Text("Cancelar")
                                .bold()
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.gray.opacity(0.5))
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }
                    }
                    .frame(width: 300)
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    .shadow(radius: 10)
                    .transition(.scale)
                }
            }
        )
        .animation(.easeInOut, value: showPopup)
    }
}

#Preview {
    HomeView2()
}
