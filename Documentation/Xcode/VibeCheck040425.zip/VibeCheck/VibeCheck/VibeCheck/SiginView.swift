//
//  SiginView.swift
//  VibeCheck
//
//  Created by Cecilia Soriano  on 27/03/25.
//

import SwiftUI

struct SignUpView: View {
    @State private var username: String = ""
    @State private var password: String = ""
    @State private var confirmPassword: String = ""

    @State private var isPasswordVisible = false
    @State private var isConfirmPasswordVisible = false

    var body: some View {
        ZStack {
            Color(red: 0/255, green: 17/255, blue: 58/255) // Fondo #00113A
                .ignoresSafeArea()

            VStack {
                Spacer()

                Text("Sign Up")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(Color(red: 255/255, green: 219/255, blue: 39/255)) // #FFDB27
                    .padding(.bottom, 20)

                VStack(alignment: .leading, spacing: 10) {
                    Text("User name")
                        .font(.headline)
                        .foregroundColor(.white)

                    TextField("Enter your username", text: $username)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)

                    Text("Password")
                        .font(.headline)
                        .foregroundColor(.white)

                    HStack {
                        Group {
                            if isPasswordVisible {
                                TextField("Enter your password", text: $password)
                            } else {
                                SecureField("Enter your password", text: $password)
                            }
                        }
                        .padding()

                        Button(action: {
                            isPasswordVisible.toggle()
                        }) {
                            Image(systemName: isPasswordVisible ? "eye.slash" : "eye")
                                .foregroundColor(.gray)
                        }
                        .padding(.trailing, 8)
                    }
                    .background(Color(.systemGray6))
                    .cornerRadius(10)

                    Text("Confirm Password")
                        .font(.headline)
                        .foregroundColor(.white)

                    HStack {
                        Group {
                            if isConfirmPasswordVisible {
                                TextField("Confirm your password", text: $confirmPassword)
                            } else {
                                SecureField("Confirm your password", text: $confirmPassword)
                            }
                        }
                        .padding()

                        Button(action: {
                            isConfirmPasswordVisible.toggle()
                        }) {
                            Image(systemName: isConfirmPasswordVisible ? "eye.slash" : "eye")
                                .foregroundColor(.gray)
                        }
                        .padding(.trailing, 8)
                    }
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
                }
                .padding(.horizontal)

                Button(action: {
                    // Acción de registro
                }) {
                    Text("Sign Up")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(red: 255/255, green: 219/255, blue: 39/255)) // #FFDB27
                        .foregroundColor(Color(red: 0/255, green: 17/255, blue: 58/255)) // Texto azul
                        .cornerRadius(10)
                }
                .padding()

                Spacer()

                NavigationLink(destination: LoginView()) {
                    Text("Already have an account? Login here")
                        .foregroundColor(.white)
                        .font(.caption)
                }

                Spacer()
            }
            .padding()
        }
    }
}

#Preview {
    SignUpView()
}
