//
//  VibeCheckTests.swift
//  VibeCheckTests
//
//  Created by Cecilia Soriano  on 06/03/25.
//

import Testing
@testable import VibeCheck

struct VibeCheckTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
