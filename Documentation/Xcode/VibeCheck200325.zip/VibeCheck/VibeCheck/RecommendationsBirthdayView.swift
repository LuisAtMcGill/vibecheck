//
//  RecommendationsBirthdayView.swift
//  VibeCheck
//
//  Created by Cecilia Soriano  on 20/03/25.
//

import SwiftUI

struct RecommendationsBirthdayView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            // Sección "Today's tasks"
            HStack {
                Text("Birthday messages")
                    .font(.title3)
                    .bold()
                Spacer()
            }
            .padding(.horizontal)

            // Lista de tareas en tarjetas con estrellas
            VStack(spacing: 12) {
                
                NavigationLink(destination: SaveTextView()) {
                    TaskCard(icon: "birthday.cake.fill", author: "Kitzia", title: "For my BFF", progress: 1, total: 5, color: Color.pink.opacity(0.2))
                    }
                .buttonStyle(PlainButtonStyle())
                TaskCard(icon: "birthday.cake.fill", author: "Doris", title: "Happy B-day", progress: 3, total: 5, color: Color.blue.opacity(0.2))
                TaskCard(icon: "birthday.cake.fill", author: "Kitzia", title: "Happy day", progress: 5, total: 5, color: Color.yellow.opacity(0.2))
                TaskCard(icon: "birthday.cake.fill", author: "Doris", title: "Happy Birthday", progress: 2, total: 5, color: Color.green.opacity(0.2))
                TaskCard(icon: "birthday.cake.fill", author: "Kitzia", title: "Happy day", progress: 5, total: 5, color: Color.yellow.opacity(0.2))
                TaskCard(icon: "birthday.cake.fill", author: "Doris", title: "Happy Birthday", progress: 2, total: 5, color: Color.green.opacity(0.2))
            }
            .padding(.horizontal)
        }
    }
}

// Vista para cada tarjeta de tarea con estrellas
struct TaskCard: View {
    let icon: String
    let author: String
    let title: String
    let progress: Int
    let total: Int
    let color: Color

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(color)
                    .frame(width: 50, height: 50)
                Image(systemName: icon)
                    .foregroundColor(.blue)
                    .font(.system(size: 22))
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.body)
                Text(author)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                StarRatingView(rating: progress, total: total)
            }
            Spacer()
        }
        .padding()
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color.gray.opacity(0.2), radius: 4, x: 0, y: 2)
    }
}

// Vista personalizada para mostrar estrellas
struct StarRatingView: View {
    let rating: Int
    let total: Int

    var body: some View {
        HStack(spacing: 4) {
            ForEach(0..<total, id: \.self) { index in
                Image(systemName: index < rating ? "star.fill" : "star")
                    .foregroundColor(index < rating ? .yellow : .gray.opacity(0.5))
                    .font(.system(size: 16))
            }
        }
    }
}

#Preview {
    RecommendationsBirthdayView()
}

