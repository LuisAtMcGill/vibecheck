//
//  ProfileView.swift
//  VibeCheck
//
//  Created by Cecilia Soriano  on 16/03/25.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        VStack(spacing: 0) {
            // Sección superior con fondo azul
            VStack {
                Spacer()
                
                // Imagen de perfil
                Image(systemName: "person.circle.fill")
                    .resizable()
                    .frame(width: 80, height: 80)
                    .foregroundColor(.gray)
                    .background(Color.white.opacity(0.5))
                    .clipShape(Circle())
                
                // Nombre de usuario
                Text("doris")
                    .font(.headline)
                    .bold()
                    .foregroundColor(Color(red: 0/255, green: 17/255, blue: 58/255))
                
                Spacer()
            }
            .frame(height: 180)
            .frame(maxWidth: .infinity)
           // .background(Color(red: 0/255, green: 17/255, blue: 58/255))
            .clipShape(RoundedCornersShape(cornerRadius: 30, corners: [.bottomLeft, .bottomRight]))
            
            // Lista de tarjetas
            ScrollView {
                VStack(spacing: 12) {
                    ForEach(0..<4, id: \.self) { _ in
                        PetitionCardView()
                    }
                }
                .padding()
            }
            
        }
        .edgesIgnoringSafeArea(.bottom)
    }
}

// Tarjeta de "Scholar petition"
struct PetitionCardView: View {
    var body: some View {
        HStack {
            Text("Scholar petition")
                .font(.body)
                .bold()
                .foregroundColor(.black)
            
            Spacer()
            
            Image(systemName: "bookmark.fill")
                .resizable()
                .frame(width: 20, height: 20)
                .foregroundColor(.yellow)
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color.gray.opacity(0.2), radius: 5, x: 0, y: 2)
    }
}



// Forma personalizada para bordes redondeados en solo la parte inferior
struct RoundedCornersShape: Shape {
    var cornerRadius: CGFloat
    var corners: UIRectCorner
    
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: cornerRadius, height: cornerRadius))
        return Path(path.cgPath)
    }
}

#Preview {
    ProfileView()
}
