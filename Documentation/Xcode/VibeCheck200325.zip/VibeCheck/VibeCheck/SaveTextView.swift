//
//  SaveTextView.swift
//  VibeCheck
//
//  Created by Cecilia Soriano on 20/03/25.
//

import SwiftUI

struct SaveTextView: View {
    @State private var showPopup = false
    @State private var selectedText = ""
    @State private var rating: Int = 3 // Estado para la calificación del mensaje

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    
                    // 📌 **Título en la parte superior**
                    Text("For my BFF")
                        .font(.title)
                        .bold()
                        .foregroundColor(Color(red: 157/255, green: 155/255, blue: 155/255))
                    
                    Text("Kitzia")
                        .foregroundColor(.gray)
                    
                    VStack {
                      
                        StarRatingView(rating: rating, total: 5)
                            .onTapGesture {
                                rating = (rating % 5) + 1 // Alternar calificación con cada toque
                            }
                    }
                    .padding(.top, 8)
                    
                    Divider()
                    HStack {
                        TagView(text: "friend")
                        TagView(text: "happy")
                        TagView(text: "birthday")
                    }
                    .padding(.bottom, 10)
                    
                    
                    Text("Espero que tengas un día increíble, lleno de alegría, risas y muchas sorpresas. Eres una persona increíble, y me alegra muchísimo tenerte en mi vida. Disfruta cada momento, come mucho pastel 🎂 y celebra a lo grande. ¡Te mereces lo mejor hoy y siempre! 🎁🎈🎊")
                        .multilineTextAlignment(.center)
                        .padding()
                    
                   
                   

                }
                .padding()
            }
        }
        
    }
}


#Preview {
    SaveTextView()
}
