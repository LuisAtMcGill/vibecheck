//
//  MainTabView.swift
//  VibeCheck
//
//  Created by Cecilia Soriano  on 20/03/25.
//

import SwiftUI

struct MainTabView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Image(systemName: "house.fill")
                    
                }
            
            RecommendationsView()
                .tabItem {
                    Image(systemName: "star.fill")
                    
                }

            ProfileView()
                .tabItem {
                    Image(systemName: "person.fill")
                   
                }
        }
    }
}

#Preview {
    MainTabView()
}
