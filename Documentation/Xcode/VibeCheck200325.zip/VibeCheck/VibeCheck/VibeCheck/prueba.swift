import SwiftUI

struct TodaysTasksView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            // Sección "Today's tasks"
            HStack {
                Text("Birthday messages")
                    .font(.title3)
                    .bold()
                Spacer()
            }
            .padding(.horizontal)

            // Lista de tareas en tarjetas con estrellas
            VStack(spacing: 12) {
                TaskCard(icon: "birthday.cake.fill", author: "kitzia", title: "For my BFF", progress: 1, total: 5, color: Color.pink.opacity(0.2))
                TaskCard(icon: "birthday.cake.fill", author: "Doris", title: "Happy B-day", progress: 3, total: 5, color: Color.blue.opacity(0.2))
                TaskCard(icon: "birthday.cake.fill", author: "Kitzia", title: "Happy day", progress: 5, total: 5, color: Color.yellow.opacity(0.2))
                TaskCard(icon: "birthday.cake.fill", author: "Doris", title: "Happy Birthday", progress: 2, total: 5, color: Color.green.opacity(0.2))
                TaskCard(icon: "birthday.cake.fill", author: "Kitzia", title: "Happy day", progress: 5, total: 5, color: Color.yellow.opacity(0.2))
                TaskCard(icon: "birthday.cake.fill", author: "Doris", title: "Happy Birthday", progress: 2, total: 5, color: Color.green.opacity(0.2))
            }
            .padding(.horizontal)
        }
    }
}




#Preview {
    TodaysTasksView()
}
