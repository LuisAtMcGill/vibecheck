//
//  VibeCheckApp.swift
//  VibeCheck
//
//  Created by Cecilia Soriano  on 06/03/25.
//

import SwiftUI

@main
struct VibeCheckApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
