//
//  HomeView.swift
//  VibeCheck
//
//  Created by Cecilia Soriano  on 06/03/25.
//

import SwiftUI

struct HomeView: View {
    @State private var showPopup = false
    @State private var selectedText = ""

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    
                    // 📌 **Título en la parte superior**
                    Text("Title")
                        .font(.title)
                        .bold()
                        .foregroundColor(Color(red: 157/255, green: 155/255, blue: 155/255))
                    
                    Divider()
                    
                    // 📌 **Etiquetas**
                    HStack {
                        TagView(text: "scholar")
                        TagView(text: "petition")
                        TagView(text: "apologize")
                    }
                    .padding(.bottom, 10)
                    
                    // 📌 **Texto con palabras subrayadas interactivas**
                    Group {
                        Text("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ")
                        
                        Text("incididunt ut labore et dolore magna aliqua.")
                            .foregroundColor(.black)
                            .background(Color.yellow.opacity(0.5))
                            .onTapGesture {
                                selectedText = "Ut enim ad minim veniam"
                                showPopup = true
                            }
                        
                        Text("Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea ")
                        
                        Text("commodo consequat.")
                            .foregroundColor(.white)
                            .background(Color.blue.opacity(0.8))
                            .cornerRadius(5)
                            .onTapGesture {
                                selectedText = "Explicación: 'Commodo consequat' se usa para referirse a un beneficio adicional."
                                showPopup = true
                            }
                        
                        Text("Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa ")
                        
                        Text("qui officia deserunt")
                            .foregroundColor(.white)
                            .background(Color.red.opacity(0.7))
                            .cornerRadius(5)
                            .onTapGesture {
                                selectedText = "Explicación: 'Qui officia deserunt' hace referencia a aquellos que causan daño."
                                showPopup = true
                            }
                        
                        Text(" mollit anim id est laborum.")
                    }
                    .font(.system(size: 18))
                }
                .padding()
            }
        }
        
        // 📌 **Popup emergente**
        .overlay(
            Group {
                if showPopup {
                    Color.black.opacity(0.3)
                        .edgesIgnoringSafeArea(.all)
                        .onTapGesture {
                            showPopup = false
                        }

                    VStack(spacing: 15) {
                        HStack {
                            Image(systemName: "bubble.left.fill")
                                .foregroundColor(.blue)
                                .font(.title)
                            Spacer()
                        }
                        
                        Text(selectedText)
                            .padding()
                            .multilineTextAlignment(.center)
                            .foregroundColor(.gray)

                        Button(action: {
                            showPopup = false
                        }) {
                            Text("Cambiar")
                                .bold()
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }
                    }
                    .frame(width: 300)
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    .shadow(radius: 10)
                    .transition(.scale)
                }
            }
        )
        .animation(.easeInOut, value: showPopup)
    }
}

// 📌 **Componente de etiquetas**
struct TagView: View {
    var text: String

    var body: some View {
        Text(text)
            .font(.caption)
            .bold()
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(Color(red: 0/255, green: 17/255, blue: 58/255))
            .foregroundColor(.white)
            .cornerRadius(10)
    }
}



#Preview {
    HomeView()
}
